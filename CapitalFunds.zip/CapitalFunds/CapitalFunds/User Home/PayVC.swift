//
//  PayVC.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import UIKit

class PayVC: UIViewController {
    
    var person = ""
    
    @IBOutlet var personToPay: UILabel!
    @IBOutlet var amountToTransfer: UITextField!
    @IBOutlet var transferDescription: UITextView!
    @IBOutlet var payButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        personToPay.text = person
        
        
        //Set frame around the description
        transferDescription.backgroundColor = .clear
        transferDescription.layer.cornerRadius = 5
        transferDescription.layer.borderWidth = 1
        transferDescription.layer.borderColor = UIColor.black.cgColor
        
        //Set frame around pay button
        payButton.backgroundColor = .clear
        payButton.layer.cornerRadius = 5
        payButton.layer.borderWidth = 1
        payButton.layer.borderColor = UIColor.blue.cgColor
    }
    
    
    @IBAction func payButtonWasPressed(_ sender: UIButton) {
        transferDescription.text = "Your money is currenlty being transfered to an offshore account..."
    }
    
    
    

}
