//
//  RecipientTableView.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import UIKit

class RecipientTableView: UITableViewController {
    
    var names = [String]()
    var usernames = [String]()
    var nameToPass = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        names = ["Sam Peak", "Christian", "Sam Hendricksen", "Ford Hendrix"]
        usernames = ["@SamHighPeaks", "@MoneyMaker37", "@SamSpeed", "@FordTheFifth"]

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 4
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        cell.textLabel!.text = names[indexPath.row]
        cell.detailTextLabel!.text = usernames[indexPath.row]

        return cell
    }
    
    // Tapping a row (movie) displays a trailer
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        nameToPass = names[indexPath.row]
        
        // Perform the segue named CityMap
        performSegue(withIdentifier: "paySegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "paySegue" {
            let payvc: PayVC = segue.destination as! PayVC
            
            //Data to pass
            payvc.person = nameToPass
        }
        
    }
 
}
