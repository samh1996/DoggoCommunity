//
//  RegisterUserVC.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import UIKit

class RegisterUserVC: UIViewController {
    
    @IBOutlet var nameField: UITextField!
    @IBOutlet var usernameField: UITextField!
    @IBOutlet var passwordField: UITextField!
    @IBOutlet var emailField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func registerUserButtonPressed(_ sender: UIButton) {
        if nameField.text != nil && usernameField.text != nil && passwordField.text != nil && emailField.text != nil {
            AuthService.instance.registerUserWithData(withName: nameField.text!, username: usernameField.text!, email: emailField.text!, andPassword: passwordField.text!, userCreationComplete: { (success, registrationError) in
                if success {
                    AuthService.instance.registerUserWithData(withName: self.nameField.text!, username: self.usernameField.text!, email: self.emailField.text!, andPassword: self.passwordField.text!, userCreationComplete: { (success, nil) in
                        self.dismiss(animated: true, completion: nil)
                        
                    })
                } else {
                    print(String(describing: registrationError?.localizedDescription))
                }
            })
            
        }
        
    }
    
    

}
