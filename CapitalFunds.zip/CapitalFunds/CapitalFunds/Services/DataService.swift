//
//  DataService.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import Foundation
import Firebase

let DB_Base = Database.database().reference()

class DataService {
    static let instance = DataService()
    
    private var _REF_BASE = DB_Base
    private var _REF_USERS = DB_Base.child("users")
    private var _REF_BUSINESS = DB_Base.child("business")
    
    var REF_BASE: DatabaseReference {
        return _REF_BASE
    }
    
    var REF_USERS: DatabaseReference {
        return _REF_USERS
    }
    
    var REF_BUSINESS: DatabaseReference {
        return _REF_BUSINESS
    }
    
    
    func createDBUser(uid: String, name: String, username: String, userData: Dictionary<String,
        Any>) {
        REF_USERS.child(uid).updateChildValues(userData)
        REF_USERS.child(uid).updateChildValues(["name": name, "username": username])
    }
    
    
    
    
}
