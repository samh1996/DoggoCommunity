//
//  ProfileVC.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var bankButton: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        bankButton.backgroundColor = .clear
        bankButton.layer.cornerRadius = 5
        bankButton.layer.borderWidth = 1
        bankButton.layer.borderColor = UIColor.blue.cgColor
    }
    
    
    

}


extension ProfileVC: UITableViewDelegate, UITableViewDataSource {
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? ProfileCell else { return UITableViewCell() }
        
        
        return cell
    }
    
    
    
    
    
    
}
