//
//  UserSettingsVC.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import UIKit

class UserSettingsVC: UIViewController {
    
    @IBOutlet var bankButton: UIButton!
    @IBOutlet var cardButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        //Put a frame around the button
        bankButton.backgroundColor = .clear
        bankButton.layer.cornerRadius = 5
        bankButton.layer.borderWidth = 1
        bankButton.layer.borderColor = UIColor.blue.cgColor
        
        //Put a frame around the button
        cardButton.backgroundColor = .clear
        cardButton.layer.cornerRadius = 5
        cardButton.layer.borderWidth = 1
        cardButton.layer.borderColor = UIColor.blue.cgColor
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

}
