//
//  ProfileCell.swift
//  CapitalFunds
//
//  Created by Sam Hendricksen on 2/17/18.
//  Copyright © 2018 Sam Hendricksen. All rights reserved.
//

import UIKit

class ProfileCell: UITableViewCell {
    
    @IBOutlet var whoPaidWho: UILabel!
    @IBOutlet var timePaid: UILabel!
    @IBOutlet var paymentDescription: UITextView!
    @IBOutlet var profileImage: UIImageView!
    

    
/*
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
*/

}
